<?php

class Database
{
  const DB_DSN = 'mysql:host=localhost;dbname=php0423e2_project;charset=utf8';
  const DB_USERNAME = 'root';
  const DB_PASSWORD = '';
}
